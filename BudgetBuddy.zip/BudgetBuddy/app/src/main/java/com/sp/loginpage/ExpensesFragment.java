package com.sp.loginpage;

import static com.sp.loginpage.astradb.Cassandra_Token;

import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class ExpensesFragment extends Fragment {

    private Button yesterdayDate;
    private Button textDate;
    private Button selectDate;
    private Button selectedButton;
    private EditText editAmount;
    private Spinner spinnerAccount;
    private Button addTransaction;
    private RadioButton selectedRadioButton;
    private RadioButton[] radioButtons;
    private EditText Comments;
    private String selectedDate;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_expenses, container, false);

        yesterdayDate = view.findViewById(R.id.yesterday_date);
        textDate = view.findViewById(R.id.text_date);
        selectDate = view.findViewById(R.id.select_date);
        editAmount = view.findViewById(R.id.edit_amount);
        addTransaction = view.findViewById(R.id.expenses_transaction);
        Comments = view.findViewById(R.id.comments);
        spinnerAccount = view.findViewById(R.id.spinner_account);

        // Set the current date
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
        String currentDate = dateFormat.format(calendar.getTime());
        textDate.setText("Today: " + currentDate);
        selectedDate = currentDate; // Default to today's date

        calendar.add(Calendar.DAY_OF_YEAR, -1); // Subtract one day
        String yesterdayDateString = dateFormat.format(calendar.getTime());
        yesterdayDate.setText("Yest: " + yesterdayDateString);

        // Restore the calendar date to today
        calendar.add(Calendar.DAY_OF_YEAR, 1);

        // Date button click listener
        View.OnClickListener dateClickListener = v -> {
            if (selectedButton != null) {
                selectedButton.setBackgroundColor(getResources().getColor(android.R.color.transparent)); // Reset previous button
                selectedButton.setTextColor(getResources().getColor(android.R.color.black)); // Reset previous button text color
            }
            selectedButton = (Button) v;
            selectedButton.setBackgroundColor(getResources().getColor(android.R.color.holo_blue_light)); // Highlight selected button
            selectedButton.setTextColor(getResources().getColor(android.R.color.white)); // Highlight selected button text color

            if (v.getId() == R.id.text_date) {
                selectedDate = currentDate;
            } else if (v.getId() == R.id.yesterday_date) {
                selectedDate = yesterdayDateString;
            } else {
                // For the selectDate button, you can implement a DatePickerDialog to let the user choose a date
                showDatePickerDialog();
            }
        };

        // Set click listeners for date buttons
        textDate.setOnClickListener(dateClickListener);
        yesterdayDate.setOnClickListener(dateClickListener);
        selectDate.setOnClickListener(dateClickListener);

        // Initialize radio buttons
        radioButtons = new RadioButton[]{
                view.findViewById(R.id.radio_food),
                view.findViewById(R.id.radio_transport),
                view.findViewById(R.id.radio_groceries),
                view.findViewById(R.id.radio_shopping),
                view.findViewById(R.id.radio_bills),
                view.findViewById(R.id.radio_insurance),
                view.findViewById(R.id.radio_health),
                view.findViewById(R.id.radio_others)
        };

        for (RadioButton radioButton : radioButtons) {
            radioButton.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (isChecked) {
                    for (RadioButton rb : radioButtons) {
                        if (rb.getId() != buttonView.getId()) {
                            rb.setChecked(false);
                        }
                    }
                    selectedRadioButton = radioButton;
                }
            });
        }

        addTransaction.setOnClickListener(v -> addTransaction());

        // Fetch accounts and set up the Spinner
        fetchAccounts();

        return view;
    }

    private void showDatePickerDialog() {
        Calendar calendar = Calendar.getInstance();
        DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(),
                (view, year, month, dayOfMonth) -> {
                    calendar.set(year, month, dayOfMonth);
                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                    selectedDate = dateFormat.format(calendar.getTime());
                    selectDate.setText("Selected: " + selectedDate);
                },
                calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.show();
    }

    private void fetchAccounts() {
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("BudgetBuddyPrefs", getActivity().MODE_PRIVATE);
        String userId = sharedPreferences.getString("USERNAME", "");

        String url = astradb.accounts + "/?where={\"username\":{\"$eq\":\"" + userId + "\"}}";
        RequestQueue queue = Volley.newRequestQueue(getActivity());

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    try {
                        JSONArray accountsArray = response.getJSONArray("data");
                        List<String> accountsList = new ArrayList<>();
                        for (int i = 0; i < accountsArray.length(); i++) {
                            JSONObject accountObject = accountsArray.getJSONObject(i);
                            String accountName = accountObject.getString("account_name");
                            accountsList.add(accountName);
                        }

                        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(),
                                android.R.layout.simple_spinner_item, accountsList);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spinnerAccount.setAdapter(adapter);
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Log.e("JSONException", e.toString());
                        Toast.makeText(getActivity(), "Failed to load accounts", Toast.LENGTH_LONG).show();
                    }
                },
                error -> {
                    String errorMessage = "Failed to fetch accounts";
                    Toast.makeText(getActivity(), errorMessage, Toast.LENGTH_LONG).show();
                }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("X-Cassandra-Token", Cassandra_Token);
                return headers;
            }
        };

        queue.add(jsonObjectRequest);
    }

    private void addTransaction() {
        // Get input values
        String amount = editAmount.getText().toString().trim();
        String comments = Comments.getText().toString().trim();
        String category = selectedRadioButton != null ? selectedRadioButton.getText().toString() : "";

        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("BudgetBuddyPrefs", getActivity().MODE_PRIVATE);
        String userId = sharedPreferences.getString("USERNAME", "");
        String selectedAccountName = spinnerAccount.getSelectedItem().toString();

        if (amount.isEmpty() || category.isEmpty() || userId.isEmpty()) {
            Toast.makeText(getActivity(), "Amount, category, and user ID cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create a JSON object from the parameters
        Map<String, Object> params = new HashMap<>();
        params.put("transaction_id", UUID.randomUUID().toString());
        params.put("user_id", userId);
        params.put("amount", Float.parseFloat(amount));
        params.put("date", selectedDate);
        params.put("category", category);
        params.put("description", comments);
        params.put("type", "expense");

        JSONObject postData = new JSONObject(params);

        RequestQueue queue = Volley.newRequestQueue(getActivity());
        String url = astradb.transactions;

        // Log the URL for debugging purposes
        Log.d("ExpensesDebug", "Transaction URL: " + url);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, postData,
                response -> {
                    Toast.makeText(getActivity(), "Transaction added successfully", Toast.LENGTH_LONG).show();
                    editAmount.setText("");
                    Comments.setText("");
                    for (RadioButton radioButton : radioButtons) {
                        radioButton.setChecked(false);
                    }
                    updateAccountBalance(selectedAccountName, -Float.parseFloat(amount));
                },
                error -> {
                    String errorMessage = "Failed to add transaction";
                    Toast.makeText(getActivity(), errorMessage, Toast.LENGTH_LONG).show();
                }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("X-Cassandra-Token", Cassandra_Token);
                headers.put("Accept", "application/json");
                // Log headers
                Log.d("ExpensesDebug", "Headers: " + headers.toString());
                return headers;
            }
        };

        // Add the request to the Volley queue
        queue.add(jsonObjectRequest);
    }

    private void updateAccountBalance(String accountName, float amount) {
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("BudgetBuddyPrefs", getActivity().MODE_PRIVATE);
        String userId = sharedPreferences.getString("USERNAME", "");

        // Construct the where clause correctly
        String url = astradb.accounts + "/?where=" + Uri.encode("{\"username\":{\"$eq\":\"" + userId + "\"},\"account_name\":{\"$eq\":\"" + accountName + "\"}}");
        RequestQueue queue = Volley.newRequestQueue(getActivity());

        JsonObjectRequest getRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    try {
                        JSONArray accountsArray = response.getJSONArray("data");
                        if (accountsArray.length() > 0) {
                            JSONObject accountObject = accountsArray.getJSONObject(0);
                            String accountId = accountObject.getString("account_id");
                            float currentAmount = (float) accountObject.getDouble("amount");
                            float newAmount = currentAmount + amount;

                            updateAmountInDatabase(accountId, newAmount);
                        } else {
                            Toast.makeText(getActivity(), "Account not found", Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(getActivity(), "Failed to retrieve account", Toast.LENGTH_LONG).show();
                    }
                },
                error -> {
                    String errorMessage = "Failed to fetch account";
                    Toast.makeText(getActivity(), errorMessage, Toast.LENGTH_LONG).show();
                }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("X-Cassandra-Token", Cassandra_Token);
                return headers;
            }
        };

        queue.add(getRequest);
    }

    private void updateAmountInDatabase(String accountId, float newAmount) {
        String url = astradb.accounts + "/" + accountId;

        Map<String, Object> params = new HashMap<>();
        params.put("amount", newAmount);

        JSONObject putData = new JSONObject(params);

        JsonObjectRequest putRequest = new JsonObjectRequest(Request.Method.PUT, url, putData,
                response -> Toast.makeText(getActivity(), "Account balance updated successfully", Toast.LENGTH_LONG).show(),
                error -> {
                    String errorMessage = "Failed to update account balance";
                    if (error.networkResponse != null) {
                        String statusCode = String.valueOf(error.networkResponse.statusCode);
                        String body = "";
                        try {
                            body = new String(error.networkResponse.data, "UTF-8");
                        } catch (UnsupportedEncodingException e) {
                            e.printStackTrace();
                        }
                        errorMessage += ": " + statusCode + " " + body;
                    } else if (error.getMessage() != null) {
                        errorMessage += ": " + error.getMessage();
                    }
                    Toast.makeText(getActivity(), errorMessage, Toast.LENGTH_LONG).show();
                }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("X-Cassandra-Token", Cassandra_Token);
                return headers;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(getActivity());
        queue.add(putRequest);
    }
}