package com.sp.loginpage;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class accounts extends navigation_drawer {

    private RecyclerView recyclerView;
    private AccountAdapter accountAdapter;
    private List<Account> accountList;
    private int volleyResponseStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getLayoutInflater().inflate(R.layout.activity_accounts, findViewById(R.id.main));

        drawerLayout = findViewById(R.id.drawer);
        ImageButton menuButton = findViewById(R.id.menu_icon);
        ImageButton addButton = findViewById(R.id.add_button);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        accountList = new ArrayList<>();

        SharedPreferences sharedPreferences = getSharedPreferences("BudgetBuddyPrefs", MODE_PRIVATE);
        String username = sharedPreferences.getString("USERNAME", "user");

        fetchAccounts(username);

        accountAdapter = new AccountAdapter(accountList);
        recyclerView.setAdapter(accountAdapter);

        if (addButton != null) {
            addButton.setOnClickListener(v -> {
                Intent intent = new Intent(accounts.this, add_account.class);
                startActivity(intent);
                finish();
            });
        }

        if (menuButton != null) {
            menuButton.setOnClickListener(v -> drawerLayout.open());
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.accounts), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void fetchAccounts(String username) {
        String url = astradb.accounts + "/?where={\"username\":{\"$eq\":\"" + username + "\"}}";
        RequestQueue queue = Volley.newRequestQueue(this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    try {

                        JSONArray dataArray = response.getJSONArray("data");
                        int userAccountCount = 0;

                        for (int i = 0; i < dataArray.length(); i++) {
                            JSONObject accountObject = dataArray.getJSONObject(i);
                            String responseUsername = accountObject.getString("username");

                            if (responseUsername.equals(username)) {
                                userAccountCount++;
                                String accountId = accountObject.getString("account_id");
                                String accountName = accountObject.getString("account_name");
                                String accountBalance = accountObject.getString("amount");
                                String category = accountObject.getString("account_type");
                                String comments = accountObject.getString("comments");
                                String createdAt = accountObject.getString("created_at");

                                Account account = new Account(accountId, accountName, accountBalance, category, comments, createdAt);
                                accountList.add(account);
                            }
                        }

                        if (userAccountCount > 0) {
                            accountAdapter.notifyDataSetChanged();
                        } else {
                            Toast.makeText(getApplicationContext(), "No accounts found for the user: " + username, Toast.LENGTH_LONG).show();
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(getApplicationContext(), "Unexpected response format: " + response.toString(), Toast.LENGTH_LONG).show();
                    }
                },
                error -> {
                    String errorMessage = "Failed to fetch accounts";
                }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("x-cassandra-token", astradb.Cassandra_Token);
                return headers;
            }

            @Override
            protected Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
                volleyResponseStatus = response.statusCode;
                return super.parseNetworkResponse(response);
            }
        };
        queue.add(jsonObjectRequest);
    }
}
