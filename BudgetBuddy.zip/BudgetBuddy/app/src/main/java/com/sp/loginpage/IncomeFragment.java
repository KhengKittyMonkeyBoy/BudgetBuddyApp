package com.sp.loginpage;

import static com.sp.loginpage.astradb.Cassandra_Token;

import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class IncomeFragment extends Fragment {

    private Button yesterdayDate;
    private Button textDate;
    private Button selectDate;
    private Button selectedButton;
    private EditText editAmount;
    private Spinner spinnerAccount;
    private Button addTransaction;
    private RadioButton selectedRadioButton;
    private RadioButton[] radioButtons;
    private EditText Comments;
    private String selectedDate;
    private Map<String, String> accountMap;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_income, container, false);

        yesterdayDate = view.findViewById(R.id.yesterday_date);
        textDate = view.findViewById(R.id.text_date);
        selectDate = view.findViewById(R.id.select_date);
        editAmount = view.findViewById(R.id.edit_amount);
        addTransaction = view.findViewById(R.id.incomes_transaction);
        Comments = view.findViewById(R.id.comments);
        spinnerAccount = view.findViewById(R.id.spinner_account);

        // Set the current date
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
        String currentDate = dateFormat.format(calendar.getTime());
        textDate.setText("Today: " + currentDate);
        selectedDate = currentDate; // Default to today's date

        calendar.add(Calendar.DAY_OF_YEAR, -1); // Subtract one day
        String yesterdayDateString = dateFormat.format(calendar.getTime());
        yesterdayDate.setText("Yest: " + yesterdayDateString);

        // Restore the calendar date to today
        calendar.add(Calendar.DAY_OF_YEAR, 1);

        // Date button click listener
        View.OnClickListener dateClickListener = v -> {
            if (selectedButton != null) {
                selectedButton.setBackgroundColor(getResources().getColor(android.R.color.transparent)); // Reset previous button
                selectedButton.setTextColor(getResources().getColor(android.R.color.black)); // Reset previous button text color
            }
            selectedButton = (Button) v;
            selectedButton.setBackgroundColor(getResources().getColor(android.R.color.holo_blue_light)); // Highlight selected button
            selectedButton.setTextColor(getResources().getColor(android.R.color.white)); // Highlight selected button text color

            if (v.getId() == R.id.text_date) {
                selectedDate = currentDate;
            } else if (v.getId() == R.id.yesterday_date) {
                selectedDate = yesterdayDateString;
            } else {
                // For the selectDate button, you can implement a DatePickerDialog to let the user choose a date
                showDatePickerDialog();
            }
        };

        // Set click listeners for date buttons
        textDate.setOnClickListener(dateClickListener);
        yesterdayDate.setOnClickListener(dateClickListener);
        selectDate.setOnClickListener(dateClickListener);

        // Initialize radio buttons
        radioButtons = new RadioButton[]{
                view.findViewById(R.id.radio_salary),
                view.findViewById(R.id.radio_allowance),
                view.findViewById(R.id.radio_investments),
                view.findViewById(R.id.radio_gifts),
                view.findViewById(R.id.radio_tips),
                view.findViewById(R.id.radio_bonuses),
                view.findViewById(R.id.radio_side_hustles),
                view.findViewById(R.id.radio_others)
        };

        for (RadioButton radioButton : radioButtons) {
            radioButton.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (isChecked) {
                    for (RadioButton rb : radioButtons) {
                        if (rb.getId() != buttonView.getId()) {
                            rb.setChecked(false);
                        }
                    }
                    selectedRadioButton = radioButton;
                }
            });
        }

        addTransaction.setOnClickListener(v -> addTransaction());

        // Initialize the account map and fetch accounts
        accountMap = new HashMap<>();
        fetchAccounts();

        return view;
    }

    private void showDatePickerDialog() {
        Calendar calendar = Calendar.getInstance();
        DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(),
                (view, year, month, dayOfMonth) -> {
                    calendar.set(year, month, dayOfMonth);
                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                    selectedDate = dateFormat.format(calendar.getTime());
                    selectDate.setText(selectedDate);
                },
                calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.show();
    }

    private void fetchAccounts() {
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("BudgetBuddyPrefs", getActivity().MODE_PRIVATE);
        String userId = sharedPreferences.getString("USERNAME", "");

        String url = astradb.accounts + "/?where={\"username\":{\"$eq\":\"" + userId + "\"}}";
        RequestQueue queue = Volley.newRequestQueue(getActivity());

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    try {
                        JSONArray accountsArray = response.getJSONArray("data");
                        List<String> accountsList = new ArrayList<>();
                        for (int i = 0; i < accountsArray.length(); i++) {
                            JSONObject accountObject = accountsArray.getJSONObject(i);
                            String accountId = accountObject.getString("account_id");
                            String accountName = accountObject.getString("account_name");
                            // Check if amount field is present
                            if (!accountObject.has("amount")) {
                                accountObject.put("amount", 0.0); // set default value
                            }
                            accountMap.put(accountName, accountId);
                            accountsList.add(accountName);
                        }

                        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(),
                                android.R.layout.simple_spinner_item, accountsList);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spinnerAccount.setAdapter(adapter);
                    } catch (JSONException e) {
                        Toast.makeText(getActivity(), "Failed to load accounts", Toast.LENGTH_LONG).show();
                    }
                },
                error -> {
                    String errorMessage = "Failed to fetch accounts";
                    Toast.makeText(getActivity(), errorMessage, Toast.LENGTH_LONG).show();
                }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("X-Cassandra-Token", Cassandra_Token);
                return headers;
            }
        };

        queue.add(jsonObjectRequest);
    }

    private void addTransaction() {
        // Get input values
        String amount = editAmount.getText().toString().trim();
        String comments = Comments.getText().toString().trim();
        String category = selectedRadioButton != null ? selectedRadioButton.getText().toString() : "";
        String accountName = (String) spinnerAccount.getSelectedItem();
        String accountId = accountMap.get(accountName);  // Get the account ID

        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("BudgetBuddyPrefs", getActivity().MODE_PRIVATE);
        String userId = sharedPreferences.getString("USERNAME", "");

        if (amount.isEmpty() || category.isEmpty() || userId.isEmpty() || accountName == null || accountId == null) {
            Toast.makeText(getActivity(), "All fields are required", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create a JSON object from the parameters
        Map<String, Object> params = new HashMap<>();
        params.put("transaction_id", UUID.randomUUID().toString());
        params.put("user_id", userId);
        params.put("amount", Float.parseFloat(amount));
        params.put("date", selectedDate);
        params.put("category", category);
        params.put("description", comments);
        params.put("type", "income");

        JSONObject postData = new JSONObject(params);

        RequestQueue queue = Volley.newRequestQueue(getActivity());
        String url = astradb.transactions;

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, postData,
                response -> {
                    Toast.makeText(getActivity(), "Transaction added successfully", Toast.LENGTH_LONG).show();
                    editAmount.setText("");
                    Comments.setText("");
                    for (RadioButton radioButton : radioButtons) {
                        radioButton.setChecked(false);
                    }
                    updateAccountBalanceInDatabase(accountId, amount, true); // Update account balance using account ID
                },
                error -> {
                    String errorMessage = "Failed to add transaction";
                    if (error.networkResponse != null) {
                        String statusCode = String.valueOf(error.networkResponse.statusCode);
                        String body = "";
                        try {
                            body = new String(error.networkResponse.data, "UTF-8");
                        } catch (UnsupportedEncodingException e) {
                            e.printStackTrace();
                        }
                        errorMessage += ": " + statusCode + " " + body;
                    } else if (error.getMessage() != null) {
                        errorMessage += ": " + error.getMessage();
                    }
                    Toast.makeText(getActivity(), errorMessage, Toast.LENGTH_LONG).show();
                }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("X-Cassandra-Token", Cassandra_Token);
                headers.put("Accept", "application/json");
                return headers;
            }
        };

        // Add the request to the Volley queue
        queue.add(jsonObjectRequest);
    }

    private void updateAccountBalanceInDatabase(String accountId, String amount, boolean isIncome) {
        Log.d("UpdateBalance", "Updating balance for account ID: " + accountId);
        RequestQueue queue = Volley.newRequestQueue(getActivity());
        String url = astradb.accounts + "/" + accountId;

        JsonObjectRequest fetchRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    Log.d("UpdateBalance", "API Response: " + response.toString());
                    try {
                        JSONArray dataArray = response.getJSONArray("data");
                        if (dataArray.length() > 0) {
                            JSONObject accountData = dataArray.getJSONObject(0);
                            if (accountData.has("amount")) {
                                double currentBalance = accountData.getDouble("amount");
                                double transactionAmount = Double.parseDouble(amount);
                                double newBalance = isIncome ? currentBalance + transactionAmount : currentBalance - transactionAmount;

                                // Update the balance
                                Map<String, Object> params = new HashMap<>();
                                params.put("amount", newBalance);
                                JSONObject postData = new JSONObject(params);

                                JsonObjectRequest updateRequest = new JsonObjectRequest(Request.Method.PUT, url, postData,
                                        updateResponse -> Log.d("BalanceUpdate", "Account balance updated successfully"),
                                        error -> {
                                            String errorMessage = "Failed to update account balance";
                                            if (error.networkResponse != null) {
                                                String statusCode = String.valueOf(error.networkResponse.statusCode);
                                                String body = "";
                                                try {
                                                    body = new String(error.networkResponse.data, "UTF-8");
                                                } catch (UnsupportedEncodingException e) {
                                                    e.printStackTrace();
                                                }
                                                errorMessage += ": " + statusCode + " " + body;
                                            } else if (error.getMessage() != null) {
                                                errorMessage += ": " + error.getMessage();
                                            }
                                            Log.e("BalanceUpdateError", errorMessage);
                                        }) {
                                    @Override
                                    public Map<String, String> getHeaders() {
                                        Map<String, String> headers = new HashMap<>();
                                        headers.put("Content-Type", "application/json");
                                        headers.put("X-Cassandra-Token", Cassandra_Token);
                                        return headers;
                                    }
                                };

                                queue.add(updateRequest);
                            }
                        }
                    } catch (JSONException e) {
                        Log.e("UpdateBalance", "Error parsing account data", e);
                    }
                },
                error -> {
                    String errorMessage = "Error fetching account data";
                    Toast.makeText(getActivity(), errorMessage, Toast.LENGTH_LONG).show();
                }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("X-Cassandra-Token", Cassandra_Token);
                return headers;
            }
        };

        queue.add(fetchRequest);
    }
}