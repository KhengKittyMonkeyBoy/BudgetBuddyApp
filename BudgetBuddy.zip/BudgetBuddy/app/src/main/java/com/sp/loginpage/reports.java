package com.sp.loginpage;

import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class reports extends navigation_drawer {

    DrawerLayout drawerLayout;
    RecyclerView insightsRecyclerView;
    InsightsAdapter insightsAdapter;
    ArrayList<String> insightsList = new ArrayList<>();
    ArrayList<String> headersList = new ArrayList<>(); // Add this line
    String selectedPeriod = "Monthly";
    String monthlyInsights = "";
    String weeklyInsights = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getLayoutInflater().inflate(R.layout.reports, findViewById(R.id.main));

        drawerLayout = findViewById(R.id.drawer);
        ImageButton menuButton = findViewById(R.id.menu_icon);

        insightsRecyclerView = findViewById(R.id.insights_recycler_view);
        insightsRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Pass both lists to the adapter
        insightsAdapter = new InsightsAdapter(headersList, insightsList);
        insightsRecyclerView.setAdapter(insightsAdapter);

        Spinner periodSpinner = findViewById(R.id.period_spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.period_options, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        periodSpinner.setAdapter(adapter);
        periodSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedPeriod = parent.getItemAtPosition(position).toString();
                if (selectedPeriod.equals("Monthly") && !monthlyInsights.isEmpty()) {
                    headersList.clear();
                    insightsList.clear();
                    // Add headers and insights according to your data
                    headersList.add("Monthly Insight");
                    insightsList.add(monthlyInsights);
                    insightsAdapter.notifyDataSetChanged();
                } else if (selectedPeriod.equals("Weekly") && !weeklyInsights.isEmpty()) {
                    headersList.clear();
                    insightsList.clear();
                    // Add headers and insights according to your data
                    headersList.add("Weekly Insight");
                    insightsList.add(weeklyInsights);
                    insightsAdapter.notifyDataSetChanged();
                } else {
                    fetchAndDisplayInsights();
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        if (menuButton != null) {
            menuButton.setOnClickListener(v -> drawerLayout.open());
        }

        fetchAndDisplayInsights();
    }

    private void fetchAndDisplayInsights() {
        SharedPreferences sharedPreferences = getSharedPreferences("BudgetBuddyPrefs", MODE_PRIVATE);
        String userId = sharedPreferences.getString("USERNAME", "");

        String whereClause = "{\"user_id\":{\"$eq\":\"" + userId + "\"}}";
        String url = astradb.transactions + "?where=" + Uri.encode(whereClause);

        Log.d("fetchAndDisplayInsights", "URL: " + url);

        RequestQueue queue = Volley.newRequestQueue(this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    try {
                        JSONArray transactionsArray = response.getJSONArray("data");
                        Log.d("fetchAndDisplayInsights", "Transactions: " + transactionsArray.toString());
                        processTransactions(transactionsArray);
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(getApplicationContext(), "Failed to load transactions", Toast.LENGTH_LONG).show();
                    }
                },
                error -> {
                    String errorMessage = "Failed to fetch transactions";
                    Toast.makeText(getApplicationContext(), errorMessage, Toast.LENGTH_LONG).show();
                }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("X-Cassandra-Token", astradb.Cassandra_Token);
                return headers;
            }
        };

        queue.add(jsonObjectRequest);
    }

    private void processTransactions(JSONArray transactionsArray) {
        double totalExpenses = 0.0;
        String mostSpentCategory = "";
        double mostSpentAmount = 0.0;
        Map<String, Double> categoryTotals = new HashMap<>();
        Map<String, Double> weeklySpending = new HashMap<>();
        Map<String, Double> monthlySpending = new HashMap<>();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        Calendar cal = Calendar.getInstance();

        try {
            for (int i = 0; i < transactionsArray.length(); i++) {
                JSONObject transaction = transactionsArray.getJSONObject(i);
                double amount = transaction.getDouble("amount");
                String type = transaction.getString("type");
                String category = transaction.getString("category");
                String dateStr = transaction.getString("date");

                Date date = sdf.parse(dateStr);

                int week = cal.get(Calendar.WEEK_OF_YEAR);
                int month = cal.get(Calendar.MONTH) + 1
                if (type.equals("expense")) {
                    totalExpenses += amount;

                    cal.setTime(date);;
                    if (selectedPeriod.equals("Weekly")) {
                        weeklySpending.put("Week " + week, weeklySpending.getOrDefault("Week " + week, 0.0) + amount);
                    } else if (selectedPeriod.equals("Monthly")) {
                        monthlySpending.put("Month " + month, monthlySpending.getOrDefault("Month " + month, 0.0) + amount);
                    }

                    // Accumulate totals for each category
                    categoryTotals.put(category, categoryTotals.getOrDefault(category, 0.0) + amount);
                }
            }

            for (Map.Entry<String, Double> entry : categoryTotals.entrySet()) {
                if (entry.getValue() > mostSpentAmount) {
                    mostSpentAmount = entry.getValue();
                    mostSpentCategory = entry.getValue
                }
            }

            generateInsights(totalExpenses, mostSpentCategory, mostSpentAmount, weeklySpending, monthlySpending);

        } catch (JSONException | ParseException e) {
            e.printStackTrace();
        }
    }

    private void generateInsights(double totalExpenses, String mostSpentCategory, double mostSpentAmount, Map<String, Double> weeklySpending, Map<String, Double> monthlySpending) {
        String prompt = "Provide insights based on the following data and give suggestions to improve spending habits. Do not make it too long, just make it short and sweet:" +
                " total expenses = $" + totalExpenses +
                ", most spent category = " + mostSpentCategory + " ($" + mostSpentAmount + ")" +
                ", weekly spending = " + weeklySpending.toString() +
                ", monthly spending = " + monthlySpending.toString();

        new Thread(() -> {
            try {
                JSONObject json = new JSONObject();
                JSONObject part = new JSONObject();
                part.put("text", prompt);

                JSONArray partsArray = new JSONArray();
                partsArray.put(part);

                JSONObject content = new JSONObject();
                content.put("parts", partsArray);

                JSONArray contentsArray = new JSONArray();
                contentsArray.put(content);

                json.put("contents", contentsArray);

                URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key=AIzaSyC3v-trTyvKzeeQp8EBtRBfFQuPI9wN9go");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json; utf-8");
                conn.setDoOutput(true);

                try (OutputStream os = conn.getOutputStream()) {
                    byte[] input = json.toString().getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"))) {
                    StringBuilder response = new StringBuilder();
                    String responseLine;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    Log.d("generateInsights", "API Response: " + response.toString());

                    JSONObject responseObject = new JSONObject(response.toString());
                    if (responseObject.has("candidates")) {
                        JSONArray candidates = responseObject.getJSONArray("candidates");
                        if (candidates.length() > 0) {
                            JSONObject firstCandidate = candidates.getJSONObject(0);
                            JSONObject contentObj = firstCandidate.getJSONObject("content");
                            JSONArray partsArrayResponse = contentObj.getJSONArray("parts");
                            if (partsArrayResponse.length() > 0) {
                                String generatedText = partsArrayResponse.getJSONObject(0).getString("text");

                                runOnUiThread(() -> {
                                    headersList.clear();
                                    insightsList.clear();

                                    headersList.add(selectedPeriod + " Insights & Suggestions");
                                    insightsList.add(generatedText);

                                    insightsAdapter.notifyDataSetChanged();

                                    if (selectedPeriod.equals("Monthly")) {
                                        monthlyInsights = generatedText;
                                    } else if (selectedPeriod.equals("Weekly")) {
                                        weeklyInsights = generatedText;
                                    }
                                });
                            } else {
                                runOnUiThread(() -> Toast.makeText(getApplicationContext(), "No insights generated.", Toast.LENGTH_SHORT).show());
                            }
                        } else {
                            runOnUiThread(() -> Toast.makeText(getApplicationContext(), "No insights generated.", Toast.LENGTH_SHORT).show());
                        }
                    } else {
                        runOnUiThread(() -> Toast.makeText(getApplicationContext(), "Invalid API response structure.", Toast.LENGTH_SHORT).show());
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> Toast.makeText(getApplicationContext(), "Failed to generate insights.", Toast.LENGTH_SHORT).show());
            }
        }).start();
    }
}
