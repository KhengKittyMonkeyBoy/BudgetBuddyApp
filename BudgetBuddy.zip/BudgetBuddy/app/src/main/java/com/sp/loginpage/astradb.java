package com.sp.loginpage;

import android.content.Context;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;

public class astradb {
    static String region = "https://db69d2cd-011e-406c-9ae0-ddecedc9dcc5-asia-south1.apps.astra.datastax.com/api/rest/";
    static String url = region + "v2/keyspaces/budgetbuddy/";
    static String users = url + "users";
    static String transactions = url + "transactions";
    static String accounts = url + "accounts";
    static String Cassandra_Token = "AstraCS:ztRXPIQlhtyHaQvOJEsLYcvy:75c69cce12f5e5230eb5bf9466330a4513f3393499281bcafb90bcd6750a6245";

    static HashMap<String, String> getHeader() {
        HashMap<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");
        headers.put("X-Cassandra-Token", Cassandra_Token);
        headers.put("Accept", "application/json");
        return headers;
    }

    // Method to fetch expenses from the database
    public static void fetchExpenses(Context context, final VolleyCallback callback) {
        String url = transactions;
        RequestQueue queue = Volley.newRequestQueue(context);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray transactionsArray = response.getJSONArray("data");
                            callback.onSuccess(transactionsArray);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        queue.add(jsonObjectRequest);
    }

    // Interface for callback
    public interface VolleyCallback {
        void onSuccess(JSONArray result);
    }
}
