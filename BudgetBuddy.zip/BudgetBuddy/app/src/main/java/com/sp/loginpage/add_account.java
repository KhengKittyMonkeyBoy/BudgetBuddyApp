package com.sp.loginpage;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class add_account extends navigation_drawer {

    private DrawerLayout drawerLayout;
    private RadioButton selectedRadioButton;
    private RadioButton[] radioButtons;

    Calendar calendar = Calendar.getInstance();
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
    String currentDate = dateFormat.format(calendar.getTime());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getLayoutInflater().inflate(R.layout.add_account, findViewById(R.id.main));

        drawerLayout = findViewById(R.id.drawer);
        ImageButton menuButton = findViewById(R.id.menu_icon);
        Button addAccountButton = findViewById(R.id.add_account_button);
        EditText accountNameEditText = findViewById(R.id.account_name);
        EditText balanceEditText = findViewById(R.id.account_balance);
        EditText commentsEditText = findViewById(R.id.account_comments);

        RadioButton savingsRadioButton = findViewById(R.id.savings);
        RadioButton cashRadioButton = findViewById(R.id.cash);
        RadioButton checkingRadioButton = findViewById(R.id.checking);
        RadioButton emergencyFundRadioButton = findViewById(R.id.emergency_fund);
        RadioButton investmentRadioButton = findViewById(R.id.investment);
        RadioButton studentLoanRadioButton = findViewById(R.id.student_loan);
        RadioButton otherAccountRadioButton = findViewById(R.id.other_account);

        radioButtons = new RadioButton[]{
                savingsRadioButton,
                cashRadioButton,
                checkingRadioButton,
                emergencyFundRadioButton,
                investmentRadioButton,
                studentLoanRadioButton,
                otherAccountRadioButton
        };

        for (RadioButton radioButton : radioButtons) {
            radioButton.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (isChecked) {
                    for (RadioButton rb : radioButtons) {
                        if (rb.getId() != buttonView.getId()) {
                            rb.setChecked(false);
                        }
                    }
                    selectedRadioButton = radioButton;
                }
            });
        }

        addAccountButton.setOnClickListener(v -> {
            String accountName = accountNameEditText.getText().toString();
            String accountBalance = balanceEditText.getText().toString();
            String category = selectedRadioButton != null ? selectedRadioButton.getText().toString() : "";

            SharedPreferences sharedPreferences = getSharedPreferences("BudgetBuddyPrefs", Context.MODE_PRIVATE);
            String userId = sharedPreferences.getString("USERNAME", "");

            if (accountName.isEmpty() || accountBalance.isEmpty() || category.isEmpty()) {
                Toast.makeText(add_account.this, "Account name, balance, and category cannot be empty", Toast.LENGTH_SHORT).show();
                return;
            }

            Map<String, Object> params = new HashMap<>();
            params.put("account_id", UUID.randomUUID().toString());  // Ensure unique UUID for each account
            params.put("username", userId);
            params.put("account_name", accountName);
            params.put("amount", accountBalance);
            params.put("account_type", category);
            params.put("comments", commentsEditText.getText().toString());
            params.put("created_at", currentDate);

            JSONObject postData = new JSONObject(params);

            RequestQueue queue = Volley.newRequestQueue(add_account.this);
            String url = astradb.accounts;

            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, postData,
                    response -> {
                        Toast.makeText(add_account.this, "Account added successfully", Toast.LENGTH_LONG).show();
                        Intent activity = new Intent(add_account.this, accounts.class);
                        startActivity(activity);
                        finish();
                        accountNameEditText.setText("");
                        balanceEditText.setText("");
                        commentsEditText.setText("");
                        for (RadioButton radioButton : radioButtons) {
                            radioButton.setChecked(false);
                        }
                    },
                    error -> {
                        String errorMessage = "Failed to add account";
                    }) {
                @Override
                public Map<String, String> getHeaders() {
                    Map<String, String> headers = new HashMap<>();
                    headers.put("Content-Type", "application/json");
                    headers.put("X-Cassandra-Token", astradb.Cassandra_Token);
                    headers.put("Accept", "application/json");
                    Log.d("ExpensesDebug", "Headers: " + headers.toString());
                    return headers;
                }
            };

            queue.add(jsonObjectRequest);
        });

        if (menuButton != null) {
            menuButton.setOnClickListener(v -> drawerLayout.open());
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}
