package com.sp.loginpage;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class TransactionPagerAdapter extends FragmentStateAdapter {
    public TransactionPagerAdapter(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 0:
                return new DisplayExpenses();
            case 1:
                return new DisplayIncome();
            default:
                return new DisplayExpenses();
        }
    }

    @Override
    public int getItemCount() {
        return 2;
    }
}
