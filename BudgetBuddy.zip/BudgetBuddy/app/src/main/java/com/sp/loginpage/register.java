package com.sp.loginpage;

import static com.sp.loginpage.astradb.Cassandra_Token;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONObject;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

public class    register extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private EditText confirmPasswordEditText;
    private Button registerButton;
    private int volleyResponseStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        setContentView(R.layout.register);

        usernameEditText = findViewById(R.id.register_username);
        passwordEditText = findViewById(R.id.register_password);
        confirmPasswordEditText = findViewById(R.id.confirm_password);
        registerButton = findViewById(R.id.register_button);

        registerButton.setOnClickListener(view -> {
            String username = usernameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString();
            String confirmPassword = confirmPasswordEditText.getText().toString();

            if (username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                Toast.makeText(register.this, "Username or password cannot be blank", Toast.LENGTH_SHORT).show();
            } else if (!password.equals(confirmPassword)) {
                Toast.makeText(register.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            } else {
                checkUsernameAvailability(username, password);
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void checkUsernameAvailability(String username, String password) {
        RequestQueue queue = Volley.newRequestQueue(this);
        String checkUrl = astradb.users + "?where=" + Uri.encode("{\"username\": {\"$eq\": \"" + username + "\"}}");

        // First, check if the username already exists
        JsonObjectRequest checkRequest = new JsonObjectRequest(Request.Method.GET, checkUrl, null,
                response -> {
                    try {
                        if (response.getJSONArray("data").length() > 0) {
                            // Username exists
                            Toast.makeText(getApplicationContext(), "Username already exists", Toast.LENGTH_SHORT).show();
                        } else {
                            // Username does not exist, proceed with registration
                            registerNewUser(username, password);
                        }
                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(), "Error checking username: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        Log.e("CheckUsername", "Error: " + e.getMessage());
                    }
                },
                error -> {
                    String errorMessage = "Error checking username availability";
                    Toast.makeText(getApplicationContext(), errorMessage, Toast.LENGTH_LONG).show();
                }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = astradb.getHeader();
                headers.put("Content-Type", "application/json");
                headers.put("X-Cassandra-Token", Cassandra_Token);
                headers.put("Accept", "application/json");
                return headers;
            }
        };

        queue.add(checkRequest);
    }


    private void registerNewUser(String username, String password) {
        Map<String, String> params = new HashMap<>();
        params.put("username", username);
        params.put("password", password);

        JSONObject postData = new JSONObject(params);
        RequestQueue queue = Volley.newRequestQueue(this);
        String url = astradb.users;

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, postData,
                response -> {
                    Log.d("Response", response.toString());
                    if (volleyResponseStatus == 201) {
                        Toast.makeText(register.this, "Register Successful", Toast.LENGTH_LONG).show();
                        Intent activity = new Intent(register.this, MainActivity.class);
                        startActivity(activity);
                        finish();
                    } else {
                        Toast.makeText(register.this, "Unexpected response code: " + volleyResponseStatus, Toast.LENGTH_LONG).show();
                    }
                },
                error -> {
                    String errorMessage = "Registration failed";
                    Toast.makeText(getApplicationContext(), errorMessage, Toast.LENGTH_LONG).show();
                }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = astradb.getHeader();
                headers.put("Content-Type", "application/json");
                headers.put("X-Cassandra-Token", Cassandra_Token);
                headers.put("Accept", "application/json");
                Log.d("RegisterDebug", "Headers: " + headers.toString());
                return headers;
            }

            @Override
            protected Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
                volleyResponseStatus = response.statusCode;
                return super.parseNetworkResponse(response);
            }
        };
        queue.add(jsonObjectRequest);
    }
}
