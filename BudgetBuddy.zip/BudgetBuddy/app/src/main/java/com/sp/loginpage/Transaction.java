package com.sp.loginpage;

public class Transaction {
    private String category;
    private double amount;
    private String date;
    private String description;

    public Transaction(String category, double amount, String date, String description) {
        this.category = category;
        this.amount = amount;
        this.date = date;
        this.description = description;
    }

    public String getCategory() { return category; }
    public double getAmount() { return amount; }
    public String getDate() { return date; }
    public String getDescription() { return description; }
}
