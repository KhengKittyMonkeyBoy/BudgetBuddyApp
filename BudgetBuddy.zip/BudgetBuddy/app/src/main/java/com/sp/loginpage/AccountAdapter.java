package com.sp.loginpage;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AccountAdapter extends RecyclerView.Adapter<AccountAdapter.AccountViewHolder> {
    private List<Account> accountList;

    public AccountAdapter(List<Account> accountList) {
        this.accountList = accountList;
    }

    @Override
    public AccountViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.account_item, parent, false);
        return new AccountViewHolder(view);
    }

    @Override
    public void onBindViewHolder(AccountViewHolder holder, int position) {
        Account account = accountList.get(position);
        holder.accountNameTextView.setText(account.getAccountName());
        holder.accountBalanceTextView.setText(account.getAmount());

        int iconResId;
        String category = account.getCategory();

        switch (category) {
            case "Savings":
                iconResId = R.drawable.savings;
                break;
            case "Checking":
                iconResId = R.drawable.cheque;
                break;
            case "Cash":
                iconResId = R.drawable.wallet2;
                break;
            case "Student Loan":
                iconResId = R.drawable.student_loan;
                break;
            case "Emergency Fund":
                iconResId = R.drawable.emergency_fund;
                break;
            case "Investment":
                iconResId = R.drawable.investment_account;
                break;
            default:
                iconResId = R.drawable.accounts;
                break;
        }

        holder.categoryImageView.setImageResource(iconResId);

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(v.getContext(), AccountDetailActivity.class);
            intent.putExtra("accountId", account.getAccountId());
            intent.putExtra("accountName", account.getAccountName());
            intent.putExtra("accountType", account.getCategory());
            intent.putExtra("amount", account.getAmount());
            intent.putExtra("comments", account.getComments());
            intent.putExtra("createdAt", account.getCreatedAt());
            v.getContext().startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return accountList.size();
    }

    public static class AccountViewHolder extends RecyclerView.ViewHolder {
        TextView accountNameTextView;
        TextView accountBalanceTextView;
        ImageView categoryImageView;

        public AccountViewHolder(View itemView) {
            super(itemView);
            accountNameTextView = itemView.findViewById(R.id.account_name);
            accountBalanceTextView = itemView.findViewById(R.id.account_balance);
            categoryImageView = itemView.findViewById(R.id.account_icon);
        }
    }
}
