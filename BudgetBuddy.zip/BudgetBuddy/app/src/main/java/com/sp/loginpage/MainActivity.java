package com.sp.loginpage;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private EditText username;
    private EditText password;
    private int volleyResponseStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Check if user is already logged in
        SharedPreferences sharedPreferences = getSharedPreferences("BudgetBuddyPrefs", MODE_PRIVATE);
        boolean isLoggedIn = sharedPreferences.getBoolean("IS_LOGGED_IN", false);
        if (isLoggedIn) {
            // User is already logged in, navigate to home page
            Intent activity = new Intent(MainActivity.this, home_page.class);
            startActivity(activity);
            finish();
            return;
        }

        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button loginButton = findViewById(R.id.loginButton);
        Button registerButton = findViewById(R.id.register_button);
        TextView forgotPassword = findViewById(R.id.forgot_pass);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);

        loginButton.setOnClickListener(view -> {
            String usernameInput = username.getText().toString();
            String passwordInput = password.getText().toString();
            if (usernameInput.isEmpty() || passwordInput.isEmpty()) {
                Toast.makeText(MainActivity.this, "Username or password cannot be blank", Toast.LENGTH_SHORT).show();
            } else {
                try {
                    checkUserExists(usernameInput, passwordInput);
                } catch (UnsupportedEncodingException e) {
                    throw new RuntimeException(e);
                }
            }
        });

        registerButton.setOnClickListener(view -> {
            Intent activity = new Intent(MainActivity.this, register.class);
            startActivity(activity);
            finish();
        });

        forgotPassword.setOnClickListener(view -> {
            Toast.makeText(MainActivity.this, "Forgot password button clicked", Toast.LENGTH_SHORT).show();
        });
    }

    private void checkUserExists(String usernameInput, String passwordInput) throws UnsupportedEncodingException {
        String url = astradb.users + "/" + usernameInput;
        RequestQueue queue = Volley.newRequestQueue(this);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            Log.d("Response", response.toString());

                            // Accessing the "data" array
                            JSONArray dataArray = response.getJSONArray("data");
                            if (dataArray.length() == 0) {
                                Toast.makeText(getApplicationContext(), "Login Failed: Username not found", Toast.LENGTH_LONG).show();
                                return;
                            }

                            // Accessing the first object in the "data" array
                            JSONObject userObject = dataArray.getJSONObject(0);
                            String responseUsername = userObject.getString("username");
                            String responsePassword = userObject.getString("password");

                            if (usernameInput.equals(responseUsername) && passwordInput.equals(responsePassword)) {
                                Toast.makeText(getApplicationContext(), "Login Successful", Toast.LENGTH_LONG).show();

                                // Save login state in SharedPreferences
                                SharedPreferences sharedPreferences = getSharedPreferences("BudgetBuddyPrefs", MODE_PRIVATE);
                                SharedPreferences.Editor editor = sharedPreferences.edit();
                                editor.putString("USERNAME", usernameInput);
                                editor.putBoolean("IS_LOGGED_IN", true);
                                editor.apply();

                                Intent activity = new Intent(MainActivity.this, home_page.class);
                                startActivity(activity);
                                finish();
                            } else {
                                Toast.makeText(getApplicationContext(), "Login Failed: Invalid username or password", Toast.LENGTH_LONG).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(getApplicationContext(), "Unexpected response format: " + response.toString(), Toast.LENGTH_LONG).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        String errorMessage = "Login failed";
                        Toast.makeText(getApplicationContext(), errorMessage, Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("x-cassandra-token", astradb.Cassandra_Token);
                return headers;
            }

            @Override
            protected Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
                volleyResponseStatus = response.statusCode;
                return super.parseNetworkResponse(response);
            }
        };
        queue.add(jsonObjectRequest);
    }
}
