package com.sp.loginpage;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

public abstract class navigation_drawer extends AppCompatActivity {

    DrawerLayout drawerLayout;
    NavigationView navigationView;
    TextView usernameTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_navigation_drawer);

        drawerLayout = findViewById(R.id.drawer);
        ImageButton menuButton = findViewById(R.id.menu_icon);
        navigationView = findViewById(R.id.navigationView);

        // Get the header view from the navigation view
        View headerView = navigationView.getHeaderView(0);
        usernameTextView = headerView.findViewById(R.id.username);

        String loggedInUsername = getLoggedInUsername();
        usernameTextView.setText(loggedInUsername);

        SharedPreferences sharedPreferences = getSharedPreferences("BudgetBuddyPrefs", MODE_PRIVATE);
        String username = sharedPreferences.getString("USERNAME", "user");
        usernameTextView.setText("Hello, " + username);

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();

                if (itemId == R.id.home) {
                    Intent intent = new Intent(navigation_drawer.this, home_page.class);
                    startActivity(intent);
                    finish();
                } else if (itemId == R.id.accounts) {
                    Intent intent = new Intent(navigation_drawer.this, accounts.class);
                    startActivity(intent);
                    finish();
                } else if (itemId == R.id.transactions) {
                    Intent intent = new Intent(navigation_drawer.this, transactions.class);
                    startActivity(intent);
                    finish();
                } else if (itemId == R.id.reports) {
                    Intent intent = new Intent(navigation_drawer.this, reports.class);
                    startActivity(intent);
                    finish();
                } else if (itemId == R.id.logout) {
                    logout();
                }

                drawerLayout.close();

                return true;
            }
        });

        // Check if menuButton is not null before setting OnClickListener
        if (menuButton != null) {
            menuButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    drawerLayout.open();
                }
            });
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private String getLoggedInUsername() {
        // Replace with your logic to get the logged-in username
        // For example, from SharedPreferences, a database, or an authentication service
        return "LoggedInUser";
    }

    private void logout() {
        SharedPreferences sharedPreferences = getSharedPreferences("BudgetBuddyPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();  // Clear all saved data
        editor.apply();

        // Navigate back to login screen
        Intent intent = new Intent(navigation_drawer.this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
