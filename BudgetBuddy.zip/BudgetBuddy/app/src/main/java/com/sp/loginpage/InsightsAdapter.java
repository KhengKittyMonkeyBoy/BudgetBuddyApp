package com.sp.loginpage;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class InsightsAdapter extends RecyclerView.Adapter<InsightsAdapter.InsightsViewHolder> {

    private List<String> insightsList;
    private List<String> headersList;

    public InsightsAdapter(List<String> headersList, List<String> insightsList) {
        this.headersList = headersList;
        this.insightsList = insightsList;
    }

    @NonNull
    @Override
    public InsightsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_insights, parent, false);
        return new InsightsViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull InsightsViewHolder holder, int position) {
        String header = headersList.get(position);
        String insight = insightsList.get(position);
        holder.insightHeaderTextView.setText(header);
        holder.insightTextView.setText(insight);
    }

    @Override
    public int getItemCount() {
        return insightsList.size();
    }

    public static class InsightsViewHolder extends RecyclerView.ViewHolder {

        TextView insightHeaderTextView;
        TextView insightTextView;

        public InsightsViewHolder(@NonNull View itemView) {
            super(itemView);
            insightHeaderTextView = itemView.findViewById(R.id.insight_header);
            insightTextView = itemView.findViewById(R.id.insight_text_view);
        }
    }
}
