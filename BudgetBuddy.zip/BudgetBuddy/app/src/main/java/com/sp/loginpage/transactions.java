package com.sp.loginpage;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class transactions extends navigation_drawer {

    private DrawerLayout drawerLayout;
    private ViewPager2 viewPager;
    private TransactionPagerAdapter adapter;
    private List<Transaction> transactionsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        // Inflate specific content for transactions
        getLayoutInflater().inflate(R.layout.activity_transactions, findViewById(R.id.main));

        // Initialize DrawerLayout and menu button
        drawerLayout = findViewById(R.id.drawer);
        ImageButton menuButton = findViewById(R.id.menu_icon);

        // Set menu button click listener
        if (menuButton != null) {
            menuButton.setOnClickListener(v -> drawerLayout.open());
        }

        // Apply window insets for edge-to-edge display
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.transactions), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });        // Initialize ViewPager2 and set the adapter
        viewPager = findViewById(R.id.transaction_view_pager);
        adapter = new TransactionPagerAdapter(this);
        viewPager.setAdapter(adapter);

        // Set button click listeners to switch between fragments
        Button buttonExpenses = findViewById(R.id.button_expenses);
        Button buttonIncome = findViewById(R.id.button_income);

        if (buttonExpenses != null) {
            buttonExpenses.setOnClickListener(v -> viewPager.setCurrentItem(0));
        }

        if (buttonIncome != null) {
            buttonIncome.setOnClickListener(v -> viewPager.setCurrentItem(1));
        }

        // Find the FloatingActionButton and set its OnClickListener
        FloatingActionButton fabAddTransaction = findViewById(R.id.fab_add_transaction);
        if (fabAddTransaction != null) {
            fabAddTransaction.setOnClickListener(v -> {
                Intent intent = new Intent(transactions.this, add_Transactions.class);
                startActivity(intent);
            });
        }
    }
}
