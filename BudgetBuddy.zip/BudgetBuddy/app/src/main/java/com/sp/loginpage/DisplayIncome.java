package com.sp.loginpage;

import static com.sp.loginpage.astradb.Cassandra_Token;

import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class DisplayIncome extends Fragment {

    private RecyclerView recyclerView;
    private TransactionsAdapter adapter;
    private List<Transaction> transactionList;
    private SimpleDateFormat dateFormat;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.display_income, container, false);

        recyclerView = view.findViewById (R.id.recycler_view_income);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        transactionList = new ArrayList<>();
        adapter = new TransactionsAdapter(transactionList);
        recyclerView.setAdapter(adapter);

        // Initialize date format
        dateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());

        fetchTransactions();

        return view;
    }

    private void fetchTransactions() {
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("BudgetBuddyPrefs", getActivity().MODE_PRIVATE);
        String userId = sharedPreferences.getString("USERNAME", "");

        String url = astradb.transactions + "/?where=" + Uri.encode("{\"user_id\":{\"$eq\":\"" + userId + "\"}}");
        RequestQueue queue = Volley.newRequestQueue(getActivity());

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    try {
                        JSONArray transactionsArray = response.getJSONArray("data");
                        for (int i = 0; i < transactionsArray.length(); i++) {
                            JSONObject transactionObject = transactionsArray.getJSONObject(i);
                            String category = transactionObject.getString("category");
                            double amount = transactionObject.getDouble("amount");
                            String date = transactionObject.getString("date");
                            String description = transactionObject.getString("description");
                            String type = transactionObject.getString("type");

                            if (type.equals("income")) {
                                transactionList.add(new Transaction(category, amount, date, description));
                            }
                        }
                        // Sort transactions by date in descending order
                        Collections.sort(transactionList, new Comparator<Transaction>() {
                            @Override
                            public int compare(Transaction t1, Transaction t2) {
                                try {
                                    return dateFormat.parse(t2.getDate()).compareTo(dateFormat.parse(t1.getDate()));
                                } catch (ParseException e) {
                                    e.printStackTrace();
                                    return 0;
                                }
                            }
                        });
                        adapter.notifyDataSetChanged();
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(getActivity(), "Failed to load transactions", Toast.LENGTH_LONG).show();
                    }
                },
                error -> {
                    String errorMessage = "Failed to fetch transactions";
                    Toast.makeText(getActivity(), errorMessage, Toast.LENGTH_LONG).show();
                }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("X-Cassandra-Token", Cassandra_Token);
                return headers;
            }
        };

        queue.add(jsonObjectRequest);
    }
}