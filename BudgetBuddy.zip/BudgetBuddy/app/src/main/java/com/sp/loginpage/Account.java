package com.sp.loginpage;

import java.text.NumberFormat;
import java.util.Locale;

public class Account {
    private String accountId;
    private String accountName;
    private String amount;
    private String category;
    private String comments;
    private String createdAt;

    public Account(String accountId, String accountName, String amount, String category, String comments, String createdAt) {
        this.accountId = accountId;
        this.accountName = accountName;
        this.amount = formatWithCommas(amount);
        this.category = category;
        this.comments = comments;
        this.createdAt = createdAt;
    }

    private String formatWithCommas(String amount) {
        try {
            double value = Double.parseDouble(amount);
            NumberFormat formatter = NumberFormat.getInstance(Locale.US);
            return formatter.format(value);
        } catch (NumberFormatException e) {
            e.printStackTrace();
            return amount;
        }
    }

    public String getAccountId() {
        return accountId;
    }

    public String getAccountName() {
        return accountName;
    }

    public String getAmount() {
        return "Balance: $" + amount;
    }

    public String getCategory() {
        return category;
    }

    public String getComments() {
        return comments;
    }

    public String getCreatedAt() {
        return createdAt;
    }
}
