package com.sp.loginpage;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.github.mikephil.charting.components.Legend;
import android.graphics.Typeface;
import android.graphics.Color;
import com.github.mikephil.charting.components.LegendEntry;

public class home_page extends navigation_drawer {

    TextView spent;
    DrawerLayout drawerLayout;
    ImageButton addButton;
    TextView helloUserTextView;
    ImageButton wallet;
    TextView totalBalanceTextView;
    ImageButton expenses;
    PieChart pieChart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getLayoutInflater().inflate(R.layout.activity_home_page, findViewById(R.id.main));

        spent = findViewById(R.id.spent);
        drawerLayout = findViewById(R.id.drawer);
        ImageButton menuButton = findViewById(R.id.menu_icon);
        wallet = findViewById(R.id.wallet);
        expenses = findViewById(R.id.expenses);
        addButton = findViewById(R.id.add_button);
        helloUserTextView = findViewById(R.id.hello_user);
        totalBalanceTextView = findViewById(R.id.balance);
        pieChart = findViewById(R.id.pieChart);

        expenses.setOnClickListener(v -> {
            Intent intent = new Intent(home_page.this, transactions.class);
            startActivity(intent);
            finish();
        });

        wallet.setOnClickListener(v -> {
            Intent intent = new Intent(home_page.this, accounts.class);
            startActivity(intent);
            finish();
        });

        // Retrieve the username from SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("BudgetBuddyPrefs", MODE_PRIVATE);
        String username = sharedPreferences.getString("USERNAME", "user");
        helloUserTextView.setText("Hello, " + username);

        if (username != null) {
            helloUserTextView.setText("Hello, " + username);
            setUsernameInNavigationDrawer(username);
            fetchAndDisplayTotalBalance(username);
        }

        if (menuButton != null) {
            menuButton.setOnClickListener(v -> drawerLayout.open());
        }

        addButton.setOnClickListener(v -> {
            if (v.getId() == R.id.add_button) {
                Intent intent = new Intent(home_page.this, add_Transactions.class);
                startActivity(intent);
                finish();
            }
        });

        // Fetch and display the total amount spent
        fetchTotalExpenses();

        // Setup PieChart
        setupPieChart();

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.home), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void setUsernameInNavigationDrawer(String username) {
        View headerView = navigationView.getHeaderView(0);
        TextView usernameTextView = headerView.findViewById(R.id.username);
        usernameTextView.setText(username);
    }

    private void fetchAndDisplayTotalBalance(String username) {
        String url = astradb.accounts + "/?where=" + Uri.encode("{\"username\":{\"$eq\":\"" + username + "\"}}");
        RequestQueue queue = Volley.newRequestQueue(this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    try {
                        JSONArray dataArray = response.getJSONArray("data");
                        double totalBalance = 0.0;

                        for (int i = 0; i < dataArray.length(); i++) {
                            JSONObject accountObject = dataArray.getJSONObject(i);
                            String responseUsername = accountObject.getString("username");

                            if (responseUsername.equals(username)) {
                                double accountBalance = accountObject.getDouble("amount");
                                totalBalance += accountBalance;
                            }
                        }

                        totalBalanceTextView.setText(String.format("Balance: $%.2f", totalBalance));

                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(getApplicationContext(), "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                },
                error -> {
                    String errorMessage = "Failed to fetch accounts";
                    if (error.networkResponse != null && error.networkResponse.statusCode == 404) {
                        errorMessage = "Failed to fetch accounts: Username not found";
                    } else {
                        if (error.networkResponse != null) {
                            String statusCode = String.valueOf(error.networkResponse.statusCode);
                            String body = "";
                            try {
                                body = new String(error.networkResponse.data, "UTF-8");
                            } catch (UnsupportedEncodingException e) {
                                e.printStackTrace();
                            }
                            errorMessage += ": " + statusCode + " " + body;
                        } else if (error.getMessage() != null) {
                            errorMessage += ": " + error.getMessage();
                        }
                    }
                    Toast.makeText(getApplicationContext(), errorMessage, Toast.LENGTH_LONG).show();
                }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("x-cassandra-token", astradb.Cassandra_Token);
                return headers;
            }
        };
        queue.add(jsonObjectRequest);
    }

    private void fetchTotalExpenses() {
        SharedPreferences sharedPreferences = getSharedPreferences("BudgetBuddyPrefs", MODE_PRIVATE);
        String userId = sharedPreferences.getString("USERNAME", "");

        String whereClause = "{\"user_id\":{\"$eq\":\"" + userId + "\"}}";
        String url = astradb.transactions + "?where=" + Uri.encode(whereClause);

        RequestQueue queue = Volley.newRequestQueue(this);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    try {
                        JSONArray transactionsArray = response.getJSONArray("data");
                        double totalExpenses = 0.0;

                        for (int i = 0; i < transactionsArray.length(); i++) {
                            JSONObject transactionObject = transactionsArray.getJSONObject(i);
                            double amount = transactionObject.getDouble("amount");
                            String type = transactionObject.getString("type");

                            if (type.equals("expense")) {
                                totalExpenses += amount;
                            }
                        }

                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putFloat("TotalExpenses", (float) totalExpenses);
                        editor.apply();

                        spent.setText(String.format("Spent: $%.2f", totalExpenses));

                        fetchAllTransactions();

                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(getApplicationContext(), "Failed to load transactions", Toast.LENGTH_LONG).show();
                    }
                },
                error -> {
                    String errorMessage = "Failed to fetch transactions";
                    Toast.makeText(getApplicationContext(), errorMessage, Toast.LENGTH_LONG).show();
                }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("X-Cassandra-Token", astradb.Cassandra_Token);
                return headers;
            }
        };

        queue.add(jsonObjectRequest);
    }

    private void fetchAllTransactions() {
        SharedPreferences sharedPreferences = getSharedPreferences("BudgetBuddyPrefs", MODE_PRIVATE);
        String userId = sharedPreferences.getString("USERNAME", "");

        String whereClause = "{\"user_id\":{\"$eq\":\"" + userId + "\"}}";
        String url = astradb.transactions + "?where=" + Uri.encode(whereClause);

        RequestQueue queue = Volley.newRequestQueue(this);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    try {
                        JSONArray transactionsArray = response.getJSONArray("data");
                        Map<String, Float> categoryTotals = calculateCategoryTotals(transactionsArray);
                        updatePieChart(categoryTotals);
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(getApplicationContext(), "Failed to load transactions", Toast.LENGTH_LONG).show();
                    }
                },
                error -> {
                    String errorMessage = "Failed to fetch transactions";
                    if (error.networkResponse != null) {
                        String statusCode = String.valueOf(error.networkResponse.statusCode);
                        String body = "";
                        try {
                            body = new String(error.networkResponse.data, "UTF-8");
                        } catch (UnsupportedEncodingException e) {
                            e.printStackTrace();
                        }
                        errorMessage += ": " + statusCode + " " + body;
                    } else if (error.getMessage() != null) {
                        errorMessage += ": " + error.getMessage();
                    }
                    Toast.makeText(getApplicationContext(), errorMessage, Toast.LENGTH_LONG).show();
                    Log.e("OnErrorResponse", errorMessage);
                }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("X-Cassandra-Token", astradb.Cassandra_Token);
                return headers;
            }
        };

        queue.add(jsonObjectRequest);
    }

    private Map<String, Float> calculateCategoryTotals(JSONArray transactionsArray) {
        Map<String, Float> categoryTotals = new HashMap<>();

        try {
            for (int i = 0; i < transactionsArray.length(); i++) {
                JSONObject transaction = transactionsArray.getJSONObject(i);
                String type = transaction.getString("type");
                if (!"expense".equals(type)) continue;

                String category = transaction.getString("category");
                float amount = (float) transaction.getDouble("amount");

                if (categoryTotals.containsKey(category)) {
                    categoryTotals.put(category, categoryTotals.get(category) + amount);
                } else {
                    categoryTotals.put(category, amount);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return categoryTotals;
    }

    private void setupPieChart() {
        pieChart.setUsePercentValues(false);
        pieChart.getDescription().setEnabled(false);
        pieChart.setExtraOffsets(5, 10, 5, 5);
        pieChart.setDragDecelerationFrictionCoef(0.95f);
        pieChart.setDrawHoleEnabled(true);
        pieChart.setHoleColor(Color.WHITE);
        pieChart.setTransparentCircleColor(Color.WHITE);
        pieChart.setTransparentCircleAlpha(110);
        pieChart.setHoleRadius(58f);
        pieChart.setTransparentCircleRadius(61f);

        pieChart.setEntryLabelColor(Color.BLACK);
        pieChart.setEntryLabelTextSize(14f);

        Legend legend = pieChart.getLegend();
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP);
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.RIGHT);
        legend.setOrientation(Legend.LegendOrientation.VERTICAL);
        legend.setDrawInside(false);
        legend.setWordWrapEnabled(true);
        legend.setTextColor(Color.BLACK);
        legend.setTextSize(12f);
        legend.setTypeface(Typeface.DEFAULT_BOLD);
        legend.setXEntrySpace(10f);
        legend.setYEntrySpace(5f);
        legend.setYOffset(0f);
    }

    private void updatePieChart(Map<String, Float> categoryTotals) {
        List<PieEntry> entries = new ArrayList<>();

        for (Map.Entry<String, Float> entry : categoryTotals.entrySet()) {
            entries.add(new PieEntry(entry.getValue(), entry.getKey()));
        }

        PieDataSet dataSet = new PieDataSet(entries, "");
        dataSet.setSliceSpace(3f);
        dataSet.setSelectionShift(5f);
        dataSet.setColors(ColorTemplate.COLORFUL_COLORS);

        PieData data = new PieData(dataSet);
        data.setValueTextSize(14f);
        data.setValueTextColor(Color.BLACK);

        pieChart.setData(data);

        List<LegendEntry> legendEntries = new ArrayList<>();

        LegendEntry header = new LegendEntry();
        header.form = Legend.LegendForm.NONE;
        header.label = "Categories: ";
        legendEntries.add(header);

        for (int i = 0; i < entries.size(); i++) {
            LegendEntry entry = new LegendEntry();
            entry.formColor = ColorTemplate.COLORFUL_COLORS[i % ColorTemplate.COLORFUL_COLORS.length];
            entry.label = entries.get(i).getLabel();
            legendEntries.add(entry);
        }

        pieChart.getLegend().setCustom(legendEntries);

        pieChart.invalidate();
    }
}