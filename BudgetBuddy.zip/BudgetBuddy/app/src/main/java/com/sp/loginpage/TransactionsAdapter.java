package com.sp.loginpage;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class TransactionsAdapter extends RecyclerView.Adapter<TransactionsAdapter.TransactionViewHolder> {

    private List<Transaction> transactionList;

    public TransactionsAdapter(List<Transaction> transactionList) {
        this.transactionList = transactionList;
    }

    @NonNull
    @Override
    public TransactionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.transaction_item, parent, false);
        return new TransactionViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TransactionViewHolder holder, int position) {
        Transaction transaction = transactionList.get(position);
        holder.categoryTextView.setText("Type: " + transaction.getCategory());
        holder.amountTextView.setText("Amount: $" + String.valueOf(transaction.getAmount()));
        holder.dateTextView.setText("Date: " + transaction.getDate());
        holder.descriptionTextView.setText("Description: " + transaction.getDescription());
    }

    @Override
    public int getItemCount() {
        return transactionList.size();
    }

    static class TransactionViewHolder extends RecyclerView.ViewHolder {
        TextView categoryTextView, amountTextView, dateTextView, descriptionTextView;

        public TransactionViewHolder(@NonNull View itemView) {
            super(itemView);
            categoryTextView = itemView.findViewById(R.id.text_category);
            amountTextView = itemView.findViewById(R.id.text_amount);
            dateTextView = itemView.findViewById(R.id.text_date);
            descriptionTextView = itemView.findViewById(R.id.text_description);
        }
    }
}
