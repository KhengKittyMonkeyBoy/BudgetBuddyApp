package com.sp.loginpage;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.navigation.NavigationView;

import java.util.HashMap;
import java.util.Map;

public class add_Transactions extends navigation_drawer {

    private static final String TAG = "transactions";
    DrawerLayout drawerLayout;
    Button buttonExpenses, buttonIncome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_transactions);

        drawerLayout = findViewById(R.id.drawer);
        ImageButton menuButton = findViewById(R.id.menu_icon);

        // Check if menuButton is not null before setting OnClickListener
        if (menuButton != null) {
            menuButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    drawerLayout.open();
                }
            });
        }

        buttonExpenses = findViewById(R.id.button_expenses);
        buttonIncome = findViewById(R.id.button_income);

        // Set default fragment
        loadFragment(new ExpensesFragment());

        buttonExpenses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadFragment(new ExpensesFragment());
            }
        });

        buttonIncome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadFragment(new IncomeFragment());
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.add_transaction), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        NavigationView navigationView = findViewById(R.id.navigationView);

        Map<Integer, Class<?>> activityMap = new HashMap<>();
        activityMap.put(R.id.home, home_page.class);
        activityMap.put(R.id.accounts, accounts.class);
        activityMap.put(R.id.transactions, transactions.class);
        activityMap.put(R.id.reports, reports.class);

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Class<?> activityClass = activityMap.get(item.getItemId());
                if (activityClass != null) {
                    Intent intent = new Intent(add_Transactions.this, activityClass);
                    startActivity(intent);
                    drawerLayout.close();
                    finish();
                    return true;
                }
                return false;
            }
        });
    }

    private void loadFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.transaction_container, fragment);
        fragmentTransaction.commit();
    }
}
