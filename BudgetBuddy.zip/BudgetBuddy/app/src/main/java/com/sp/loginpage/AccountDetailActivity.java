package com.sp.loginpage;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class AccountDetailActivity extends AppCompatActivity {
    private TextView tvAccountName;
    private TextView tvAccountType;
    private TextView tvAmount;
    private TextView tvComments;
    private TextView tvCreatedAt;
    private ImageView ivAccountIcon;
    private Button btnDelete;
    private String accountId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.account_detail);

        tvAccountName = findViewById(R.id.tvAccountName);
        tvAccountType = findViewById(R.id.tvAccountType);
        tvAmount = findViewById(R.id.tvAmount);
        tvComments = findViewById(R.id.tvComments);
        tvCreatedAt = findViewById(R.id.tvCreatedAt);
        ivAccountIcon = findViewById(R.id.ivAccountIcon);
        btnDelete = findViewById(R.id.btnDelete);

        accountId = getIntent().getStringExtra("accountId");
        String accountName = getIntent().getStringExtra("accountName");
        String accountType = getIntent().getStringExtra("accountType");
        String amount = getIntent().getStringExtra("amount");
        String comments = getIntent().getStringExtra("comments");
        String createdAt = getIntent().getStringExtra("createdAt");

        tvAccountName.setText(accountName);
        tvAccountType.setText("Account Type: " + accountType);
        tvAmount.setText(amount);
        tvComments.setText("Comments: " + comments);
        tvCreatedAt.setText("Date Created: " + createdAt);

        int iconResId = getIconResId(accountType);
        ivAccountIcon.setImageResource(iconResId);

        btnDelete.setOnClickListener(v -> {
            new AlertDialog.Builder(AccountDetailActivity.this)
                    .setTitle("Delete Account")
                    .setMessage("Are you sure you want to delete this account?")
                    .setPositiveButton(android.R.string.yes, (dialog, which) -> deleteAccount())
                    .setNegativeButton(android.R.string.no, null)
                    .show();
        });
    }

    private int getIconResId(String accountType) {
        switch (accountType) {
            case "Savings": return R.drawable.savings;
            case "Checking": return R.drawable.cheque;
            case "Cash": return R.drawable.wallet2;
            case "Student Loan": return R.drawable.student_loan;
            case "Emergency Fund": return R.drawable.emergency_fund;
            case "Investment": return R.drawable.investment_account;
            default: return R.drawable.accounts;
        }
    }

    private void deleteAccount() {
        if (accountId == null || accountId.isEmpty()) {
            Toast.makeText(this, "Account ID is missing. Cannot delete account.", Toast.LENGTH_SHORT).show();
            return;
        }

        String url = astradb.accounts + "/" + accountId;

        JsonObjectRequest deleteRequest = new JsonObjectRequest(Request.Method.DELETE, url, null,
                response -> {

                    Toast.makeText(this, "Account deleted successfully", Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(AccountDetailActivity.this, accounts.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    finish();
                },
                error -> {
                    String errorMessage = "Failed to delete account";
                }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                headers.put("x-cassandra-token", astradb.Cassandra_Token);
                return headers;
            }

            @Override
            protected Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
                if (response.data == null || response.data.length == 0) {
                    return Response.success(null, HttpHeaderParser.parseCacheHeaders(response));
                } else {
                    return super.parseNetworkResponse(response);
                }
            }
        };

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(deleteRequest);
    }

}
